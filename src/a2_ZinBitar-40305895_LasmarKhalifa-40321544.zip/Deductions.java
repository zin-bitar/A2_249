//--------------------------------------------------------
//Assignment 2
//Written by: Zin Bitar 40305895 && Lasmar Khalifa 40321544
//---------------------------------------------------------

public abstract class Deductions {

    public abstract double calculateTax(Employee employee);
}
