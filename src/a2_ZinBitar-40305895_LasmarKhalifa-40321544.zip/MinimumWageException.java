public class MinimumWageException extends Exception {
    public MinimumWageException(String message) {
        super(message);
    }
}